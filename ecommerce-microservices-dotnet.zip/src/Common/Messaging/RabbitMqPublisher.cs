using RabbitMQ.Client;
using System;
using System.Text.Json;
namespace Common.Messaging {
    public class RabbitMqPublisher : IDisposable {
        private readonly IConnection _connection;
        public RabbitMqPublisher(string rabbitMqUri) {
            var factory = new ConnectionFactory() { Uri = new Uri(rabbitMqUri) };
            _connection = factory.CreateConnection();
        }
        public void Publish<T>(string exchange, string routingKey, T message) {
            using var channel = _connection.CreateModel();
            channel.ExchangeDeclare(exchange, ExchangeType.Direct, durable:true);
            var body = JsonSerializer.SerializeToUtf8Bytes(message);
            channel.BasicPublish(exchange, routingKey, null, body);
        }
        public void Dispose() => _connection?.Dispose();
    }
}

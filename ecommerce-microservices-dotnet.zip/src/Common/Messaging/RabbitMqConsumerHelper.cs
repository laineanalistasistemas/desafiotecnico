using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
namespace Common.Messaging {
    public static class RabbitMqConsumerHelper {
        public static void StartConsumer(string rabbitMqUri, string queue, Action<string> onMessage) {
            var factory = new ConnectionFactory() { Uri = new Uri(rabbitMqUri) };
            var conn = factory.CreateConnection();
            var channel = conn.CreateModel();
            channel.QueueDeclare(queue: queue, durable:true, exclusive:false, autoDelete:false);
            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (model, ea) => {
                var json = Encoding.UTF8.GetString(ea.Body.ToArray());
                onMessage(json);
            };
            channel.BasicConsume(queue: queue, autoAck: true, consumer: consumer);
        }
    }
}

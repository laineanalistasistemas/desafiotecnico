using System;
namespace Common.DTOs {
    public record ProductDto(Guid Id, string Name, string Sku, int Quantity);
}

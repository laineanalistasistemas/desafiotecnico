using System;
using System.Collections.Generic;
namespace Common.DTOs {
    public record OrderItemDto(Guid ProductId, int Quantity);
    public record OrderDto(string CustomerId, List<OrderItemDto> Items);
}

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using InventoryService.Data;
using Common.Messaging;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<InventoryDbContext>(opt => opt.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddControllers();
builder.Services.AddSingleton(new RabbitMqPublisher(builder.Configuration.GetValue<string>("RabbitMq:Uri")));
var app = builder.Build();
app.MapControllers();
// Optional: start a background consumer (simple)
var rabbitUri = builder.Configuration.GetValue<string>("RabbitMq:Uri");
_ = System.Threading.Tasks.Task.Run(()=> {
    Common.Messaging.RabbitMqConsumerHelper.StartConsumer(rabbitUri, "order_created_queue", json => {
        // simplistic: in real app, deserialize and reserve stock
        Console.WriteLine("InventoryService received OrderCreated: " + json);
    });
});
app.Run();

using Microsoft.AspNetCore.Mvc;
using InventoryService.Data;
using InventoryService.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase {
    private readonly InventoryDbContext _db;
    public ProductsController(InventoryDbContext db) => _db = db;
    [HttpGet]
    public IActionResult Get() => Ok(_db.Products.ToList());
    [HttpGet("{id}")]
    public IActionResult Get(Guid id) {
        var p = _db.Products.Find(id);
        if (p == null) return NotFound();
        return Ok(p);
    }
    [HttpPost]
    public async Task<IActionResult> Create(Product model) {
        model.Id = Guid.NewGuid();
        _db.Products.Add(model);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = model.Id }, model);
    }
    [HttpPut("{id}/stock")]
    public async Task<IActionResult> UpdateStock(Guid id, [FromBody]int qty) {
        var p = _db.Products.Find(id);
        if (p==null) return NotFound();
        p.Quantity = qty;
        await _db.SaveChangesAsync();
        return NoContent();
    }
}

using Microsoft.AspNetCore.Mvc;
using SalesService.Data;
using SalesService.Models;
using Common.Messaging;
using Common.DTOs;
using System;
using System.Linq;
[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase {
    private readonly SalesDbContext _db;
    private readonly RabbitMqPublisher _publisher;
    public OrdersController(SalesDbContext db, RabbitMqPublisher publisher) { _db = db; _publisher = publisher; }
    [HttpPost]
    public IActionResult Create([FromBody] OrderDto dto) {
        var order = new Order {
            Id = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow,
            CustomerId = dto.CustomerId,
            Items = dto.Items.Select(i => new OrderItem { Id = Guid.NewGuid(), ProductId = i.ProductId, Quantity = i.Quantity }).ToList(),
            Status = "Pending"
        };
        _db.Orders.Add(order);
        _db.SaveChanges();
        // Publish event (very simple)
        _publisher.Publish("orders", "OrderCreated", new { order.Id, Items = dto.Items, dto.CustomerId });
        return Accepted(new { orderId = order.Id });
    }
    [HttpGet("{id}")]
    public IActionResult Get(Guid id) {
        var o = _db.Orders.Find(id);
        if (o==null) return NotFound();
        return Ok(o);
    }
}

using Microsoft.EntityFrameworkCore;
using SalesService.Models;
namespace SalesService.Data {
    public class SalesDbContext : DbContext {
        public SalesDbContext(DbContextOptions<SalesDbContext> opts): base(opts) {}
        public DbSet<Order> Orders { get; set; }
    }
}
